class SectionsController < ApplicationController
  active_scaffold :section do |conf|
  end
end 