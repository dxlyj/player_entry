class MembersController < ApplicationController
  active_scaffold :member do |conf|
  end
end 