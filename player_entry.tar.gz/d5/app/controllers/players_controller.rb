class PlayersController < ApplicationController
  active_scaffold :player do |conf|
  end
end 