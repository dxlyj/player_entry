class Section < ActiveRecord::Base
  attr_accessible :name
end
