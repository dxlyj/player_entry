class Player < ActiveRecord::Base
  attr_accessible :acbl_number, :city, :first, :last, :number_of_mps, :section_id, :state
end
