class CreatePlayers < ActiveRecord::Migration
  def change
    create_table :players do |t|
      t.string :section_id
      t.string :acbl_number
      t.string :first
      t.string :last
      t.string :city
      t.string :state
      t.string :number_of_mps

      t.timestamps
    end
  end
end
