class CreateMembers < ActiveRecord::Migration
  def change
    create_table :members do |t|
      t.string :acbl_number
      t.string :first
      t.string :last
      t.string :city
      t.string :state
      t.string :number_of_mps

      t.timestamps
    end
  end
end
