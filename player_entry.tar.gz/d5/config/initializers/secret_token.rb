# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
D5::Application.config.secret_token = '03fd708709d0535a97922662f426bd889c2ab067979238d59b411d72c9efa6cd666354664ff89d7cdb54c79e7ef4f3d4e6d4e83f8e1bed450220c5589bfc4736'
